def sendValToArd(val):
    print(val)

def animationsForHeader(animations):
    for animation in animations:
        print(animation)
        print('-------------------------\n')
        print(animation.getSpeed())