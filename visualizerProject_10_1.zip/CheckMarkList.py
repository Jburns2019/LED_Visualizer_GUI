from tkinter import *

class CheckButtonBar:
   def __init__(self, master, listOfButtons, text, numChecks, listColorsHex, listColorNames, listValues, var, side = LEFT):
      self.var = var
      self.checkList = []
      self.dependentButtons = listOfButtons

      self.frame = LabelFrame(master, text=text)
      self.frame.pack()

      self.numButtons = numChecks
      self.colorHexes = listColorsHex
      self.colorNames = listColorNames
      self.possValues = listValues

      self.setupChecks()

   def setupChecks(self):
      for i in range(self.numButtons):
         self.checkList.append(Checkbutton(
            self.frame,
            text = self.colorNames[i],
            onvalue = self.possValues[i],
            offvalue = -1,
            variable = self.var,
            state = NORMAL,
            command = self.activateSelection,
            width = 15,
            bg = '#' + str(self.colorHexes[i])
         ))
         self.checkList[i].pack()

   def activateSelection(self):
      if self.var.get() != -1:
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = NORMAL
      
      elif self.var.get() == -1:         
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = DISABLED