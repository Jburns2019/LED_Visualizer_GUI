from tkinter import *

class SliderFrames:
    def __init__(self, frame, infos):
        self.frame = Frame(frame)
        self.frame.pack(anchor = W)

        self.listofscaleFrame_sels = [[], []]
        self.stripFrames = []

        for i in range(len(infos)):
            self.stripFrames.append(Frame(self.frame))
            self.stripFrames[i].pack()

            for j in range(len(infos[i])):
                infos[i][j].insert(0, self.stripFrames[i])
                self.listofscaleFrame_sels[i].append(self.scaleSetup(infos[i][j]))
   
    def remove(self):
        self.frame.destroy()

    def scaleSetup(self, info):
        selFrame, title, from_, to, var, command = info

        scaleFrame = LabelFrame(selFrame, text = title)
        scaleFrame.pack(side = LEFT, anchor=W)

        sel = Scale(scaleFrame, from_=from_, to=to, command = command, orient=HORIZONTAL)
        sel.set(var.get())
        sel.pack()
        return [scaleFrame, sel]