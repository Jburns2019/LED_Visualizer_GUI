from Matrix import LEDMatrix

class Animation:
    def __init__(self, x, y, z, lim, frameCnt):
        self.animation = [LEDMatrix(x, y, z, lim) for frame in range(frameCnt)]
        self.frameCnt = frameCnt
    
    def __init__(self, frameCnt):
        self.animation = [LEDMatrix() for frame in range(frameCnt)]
        self.frameCnt = frameCnt
    
    def __init__(self):
        self.animation = [LEDMatrix() for frame in range(30)]
        self.frameCnt = 30
    
    def getNumFrames(self):
        return self.frameCnt
    
    def setFrame(self, frame, matrix):
        self.animation[frame] = matrix
    
    def getFrame(self, frame):
        return self.animation[frame]

    def clearAnimation(self):
        for frame in range(frameCnt):
            self.animation[frame].clearMatrix()
    
    def toString(self):
        outStr = ''

        for frame in range(self.frameCnt):
            outStr += self.animation[frame].toString()
            if frame < self.frameCnt - 1:
                outStr += ''.join(['-' for i  in range(4 * (self.animation[frame].getxlen()-1) + 1)])
                outStr += "\n"
        
        return outStr

    def __str__(self):
        return self.toString()

# A = Animation()
# print(A)