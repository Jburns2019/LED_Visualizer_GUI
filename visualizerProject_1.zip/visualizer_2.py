#!/usr/bin/python

from tkinter import *
from tkinter import messagebox
from Matrix import LEDMatrix
from Animation import Animation

#creates initial "basic window 
class MultiWindow:
   def __init__(self, master):
      self.master = master
      self.secondaryWin = None
      
      Button(basic, text ="First Animation", width = 15, command = firstAnimation).grid(row = 0, column = 0)
      Button(basic, text ="Second Animation", width = 15, command = secondAnimation).grid(row = 0, column = 1)
      Button(basic, text ="Third Animation", width = 15, command = thirdAnimation).grid(row = 0, column = 2)
      Button(basic, text ="Fourth Animation", width = 15, command = fourthAnimation).grid(row = 1, column = 0)
      Button(basic, text ="Fifth Animation", width = 15, command = fifthAnimation).grid(row = 1, column = 1)
      Button(basic, text ="Sixth Animation", width = 15, command = sixthAnimation).grid(row = 1, column = 2)
      self.nextBtn = Button(self.master, text="Advanced Settings", width = 15, command=self.advancedSettingOptions)
      self.nextBtn.grid(row = 2, column = 1)
   
   def advancedSettingOptions(self):
      if not self.secondaryWin:
         self.secondaryWin = Toplevel()
         basicBtn = Button(self.secondaryWin, text="Basic Settings", command=self.basicSettingOptions)
         basicBtn.pack()

         self.secondaryWin.geometry("500x500")
         self.master.withdraw()

         scrollbar = Scrollbar(self.secondaryWin, jump = 0)
         scrollbar.pack( side = RIGHT, fill = Y )
         mylist = Listbox(self.secondaryWin, yscrollcommand = scrollbar.set )
         for line in range(30):
            mylist.insert(END, "Frame Number: " + str(line))
         mylist.pack(side = RIGHT, fill = BOTH)
         scrollbar.config(command = mylist.yview)
      else:
         self.secondaryWin.deiconify()
         self.master.withdraw()
      
   def basicSettingOptions(self):
      self.secondaryWin.withdraw()
      self.master.deiconify()

#Functions of animations
def firstAnimation():
   messagebox.showinfo( "UpTop1", "First")
   print(0)
def secondAnimation():
   messagebox.showinfo("UpTop2", "Second")
   print(1)
def thirdAnimation():
   messagebox.showinfo("UpTop3", "Third")
   print(2)
def fourthAnimation():
   messagebox.showinfo("UpTop4", "Fourth")
   print(3)
def fifthAnimation():
   messagebox.showinfo("UpTop5", "Fifth")
   print(4)
def sixthAnimation():
   messagebox.showinfo("UpTop6", "Sixth")
   print(5)

basic = Tk()
basic.title("LED Visualizer GUI")
basic.geometry("347x80")

window = MultiWindow(basic)
basic.mainloop()
