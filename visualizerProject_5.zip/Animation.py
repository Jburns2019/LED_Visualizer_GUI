from Matrix import LEDMatrix

class Animation:
    def __init__(self, x, y, z, lim, frameCnt, speed):
        self.animation = [LEDMatrix(x, y, z, lim) for frame in range(frameCnt)]
        self.frameCnt = frameCnt
        self.speed = speed
    
    def __init__(self, frameCnt, speed):
        self.animation = [LEDMatrix() for frame in range(frameCnt)]
        self.frameCnt = frameCnt
        self.speed = speed
    
    def __init__(self):
        self.animation = [LEDMatrix() for frame in range(30)]
        self.frameCnt = 30
        self.speed = 20
    
    def getNumFrames(self):
        return self.frameCnt
    
    def setSpeed(self, speed):
        self.speed = speed

    def getSpeed(self):
        return self.speed

    def setFrame(self, frame, matrix):
        self.animation[frame] = matrix

    def getFrame(self, frame):
        return self.animation[frame]

    def changeFrameCnt(self, newFrameCnt):
        newAnimation = self.__init__(newFrameCnt)

        for frame in range(newFrameC):
            newAnimation.setFrame(frame, self.getFrame(frame))
        
        self.animation = newAnimation

    def clearAnimation(self):
        for frame in range(frameCnt):
            self.animation[frame].clearMatrix()
    
    def toString(self):
        outStr = ''

        for frame in range(self.frameCnt):
            outStr += self.animation[frame].toString()
            if frame < self.frameCnt - 1:
                outStr += ''.join(['-' for i  in range(4 * (self.animation[frame].getxlen()-1) + 1)])
                outStr += "\n"
        
        return outStr

    def __str__(self):
        return self.toString()

# A = Animation()
# print(A)