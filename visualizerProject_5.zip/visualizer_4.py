#!/usr/bin/python

from tkinter import *
from tkinter import messagebox
from Matrix import LEDMatrix
from Animation import Animation
from ArduinoInterface import *
from Layer import LEDLayer
from CheckMarkList import CheckButtonBar
import sys
import numpy as np

Colors = {'Off': 0, 'Dim Blue': 1, 'Dim Green': 2, 'Dim Cyan': 3, \
             'Dim Red': 4, 'Dim Purple': 5, 'Dim Yellow': 6, 'Dim White': 7, \
             'Blue': 8, 'Blue-Cyan': 10, 'Blue-Purple': 12, 'Baby Blue': 14, \
             'Green': 16, 'Green-Cyan': 17, 'Green-Yellow': 20, 'Green-White': 21, \
             'Cyan': 24, 'Cyan-White': 28, 'Red': 32, 'Red-Purple': 33, \
             'Red-Yellow': 34, 'Pink': 35, 'Purple': 40, 'Purple-White': 42, \
             'Yellow': 48, 'Yellow-White': 49, 'White': 56}

HexColors = {'000000': 0, '00007f': 1, '007f00': 2, '007f7f': 3, \
             '7f0000': 4, '7f007f': 5, '7f7f00': 6, '7f7f7f': 7, \
             '0000ff': 8, '007fff': 10, '7f00ff': 12, '7f7fff': 14, \
             '00ff00': 16, '00ff7f': 17, '7fff00': 20, '7fff7f': 21, \
             '00ffff': 24, '7fffff': 28, 'ff0000': 32, 'ff007f': 33, \
             'ff7f00': 34, 'ff7f7f': 35, 'ff00ff': 40, 'ff7fff': 42, \
             'ffff00': 48, 'ffff7f': 49, 'ffffff': 56}

#creates initial "basic window 
class MultiWindow:
   def __init__(self, master, hexColors, colors):
      self.master = master
      self.secondaryWin = None
      self.hexColors = hexColors
      self.colors = colors

      self.currentBtnLst = [None]
      self.currentBtnLayer = None

      self.colorChosen = IntVar()
      self.animationChosen = IntVar()
      self.frameChosen = IntVar()
      self.layerChosen = IntVar()

      self.animations = []
      for i in range(3):
         self.animations.append(Animation())

      self.setupMainWindow()

      self.nextBtn = Button(self.master, text="Advanced Settings", width = 15, command=self.advancedSettingOptions)
      self.nextBtn.grid(row = 2, column = 1)

   def setupMainWindow(self):
      counter = 0
      for i in range(2):
         for j in range(3):
            Button(basic, text =f"Animation {counter+1}", width = 15, command = self.choiceLambda(counter)).grid(row = i, column = j)
            counter += 1

   def choiceLambda(self, num):
      return lambda: self.displayChoice(num)

   #Functions of animations
   def displayChoice(self, num):
      messagebox.showinfo(f"UpTop{num}", str(num))
      sendValToArd(num)

   def sendAnimationsLam(self, animations):
      return lambda: animationsForHeader(animations)

   def advancedSettingOptions(self):
      if not self.secondaryWin:
         self.secondaryWin = Toplevel()
         self.secondaryWin.protocol("WM_DELETE_WINDOW", sys.exit)

         tabFrame = Frame(self.secondaryWin)
         actionFrame = Frame(self.secondaryWin)
         tabFrame.pack(side = TOP, anchor = W)
         actionFrame.pack(side = TOP, anchor = W)

         self.btnFrame = None
         
         for i in range(3):
            Button(tabFrame, text =f"Animation {i+1}", width = 12, command = self.animSelectLam(i)).pack(side = LEFT)
         Button(tabFrame, text="Basic Settings", width = 12, command=self.basicSettingOptions).pack(side = LEFT)
         Button(tabFrame, text="Submit", bg = 'green', width = 12, command = self.sendAnimationsLam(self.animations)).pack(side = LEFT)

         self.secondaryWin.geometry("550x721")
         self.master.withdraw()

         self.setupActionFrame(actionFrame)
      else:
         self.secondaryWin.deiconify()
         self.master.withdraw()
      
   def basicSettingOptions(self):
      self.secondaryWin.withdraw()
      self.master.deiconify()
   
   def setupActionFrame(self, actionFrame):
      self.btnFrame = Frame(actionFrame)
      scrollFrame = Frame(actionFrame)
      colorSelFrame = Frame(actionFrame)

      colorSelFrame.pack(side = LEFT, fill = Y)
      self.btnFrame.pack(side = LEFT, fill = BOTH)
      scrollFrame.pack(side = LEFT, fill = Y)

      self.LEDSelectionSetup()
      self.scrollBarSetup(scrollFrame)
      self.colorSelectorSetup(colorSelFrame)
   
   def LEDSelectionSetup(self):      
      matrix = self.animations[self.animationChosen.get()].getFrame(self.frameChosen.get())
      self.currentBtnLayer = LEDLayer(self.btnFrame, matrix, self.colorChosen, self.layerChosen, self.hexColors)
      self.currentBtnLst[0] = self.currentBtnLayer.buttonLst

   def scrollBarSetup(self, scrollFrame):
      scrollbar = Scrollbar(scrollFrame, jump = 0)
      scrollbar.pack(side = RIGHT, fill = Y)

      mylist = Listbox(scrollFrame, yscrollcommand = scrollbar.set)
      for line in range(30):
         mylist.insert(END, "Frame Number: " + str(line))
      mylist.pack(side = RIGHT, fill = BOTH)

      scrollbar.config(command = mylist.yview)
   
   def colorSelectorSetup(self, colorSelFrame):
      CheckButtonBar(
         colorSelFrame, 
         self.currentBtnLst, 
         'Possible Colors', 
         len(list(self.colors.values())),
         list(self.hexColors.keys()),
         list(self.colors.keys()),
         list(self.hexColors.values()),
         self.colorChosen
      )
   
   def animSelectLam(self, animSelected):
      return lambda: self.animSelAct(animSelected)

   def animSelAct(self, animSelected):
      self.currentBtnLayer.remove()

      self.animationChosen.set(animSelected)

      matrix = self.animations[self.animationChosen.get()].getFrame(self.frameChosen.get())
      self.currentBtnLayer = LEDLayer(self.btnFrame, matrix, self.colorChosen, self.layerChosen, self.hexColors)
      self.currentBtnLst[0] = self.currentBtnLayer.buttonLst

basic = Tk()
basic.title("LED Visualizer GUI")
basic.geometry("347x80")

window = MultiWindow(basic, HexColors, Colors)
basic.protocol("WM_DELETE_WINDOW", basic.destroy)
basic.mainloop()
