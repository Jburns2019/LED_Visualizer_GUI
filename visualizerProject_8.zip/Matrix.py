class LEDMatrix:
    def __init__(self, *args):
        if len(args) == 4:
            x, y, z, lim = args
            self.matrix = [[[0 for k in range(z)] for j in range(y)] for i in range(x)]
            self.x = x
            self.y = y
            self.z = z
            self.lim = lim
        elif len(args) == 0:
            self.matrix = [[[0 for k in range(7)] for j in range(5)] for i in range(5)]
            self.x = 5
            self.y = 5
            self.z = 7
            self.lim = 57
    
    def getxlen(self):
        return self.x

    def getylen(self):
        return self.y

    def getzlen(self):
        return self.z
    
    def getlim(self):
        return self.lim

    def getMatrix(self):
        return self.matrix

    def setVal(self, x, y, z, val):
        wasProb = False

        if val < self.lim and val >= 0:
            self.matrix[x][y][z] = val
        else:
            wasProb = True
        
        return wasProb
    
    def getVal(self, x, y, z):
        return self.matrix[x][y][z]

    def clearVal(self, x, y, z):
        self.matrix[x][y][z] = 0
    
    def clearMatrix(self):
        self.matrix = [[[0 for k in range(self.z)] for j in range(self.y)] for i in range(self.z)]
    
    def toString(self):
        outStr = ""
        for z in range(self.z):
            for y in range(self.y):
                for x in range (self.x):
                    outStr += str(self.matrix[x][y][z])
                    if x < self.x - 1:
                        outStr += "   "
                outStr += "\n"
            if z < self.z - 1:
                outStr += "\n"
        return outStr

    def __str__(self):
        return self.toString()