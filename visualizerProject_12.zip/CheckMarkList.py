"""
Author: John Burns
Last Modified: 5/12/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

from tkinter import *

"""
Setup the check buttons for setting colors. The panel of checks is colored and named based on the colors the checks represent.
If no color is selected the listOfButtons will become disabled.
parameters: master, the frame the color pannel will be put on (Frame)
            listOfButtons, a list of the dependent buttons (list(Button))
            text, the label used for the color selection (string).
            numChecks, the number of colors anticipated (int).
            listColorsHex, list of the colors in hexadecimal (list(string))
            listColorNames, list of colors names (list(string))
            listValues, list of the numeric representation of that color (list(int))
"""
class CheckButtonBar:
   def __init__(self, master, listOfButtons, text, numChecks, listColorsHex, listColorNames, listValues, var):
      #Make parameters accessible within the class.
      self.var = var
      #prepare a list.
      self.checkList = []
      self.dependentButtons = listOfButtons

      #Make a labelFrame for describing the pannel.
      self.frame = LabelFrame(master, text=text)
      self.frame.pack()

      self.numButtons = numChecks
      self.colorHexes = listColorsHex
      self.colorNames = listColorNames
      self.possValues = listValues

      #Setup the disabling and reenabling the dependant buttons.
      self.setupChecks()

   """
   Make a list of CheckButtons that are off at -1 and on at the given numeric value.
      the variable, makes it so that the value will be accessible elsewhere without having to check it (auto updates).
   """
   def setupChecks(self):
      #Make a list of CheckButtons and put them in the named pannel.
      for i in range(self.numButtons):
         self.checkList.append(Checkbutton(
            self.frame,
            text = self.colorNames[i],
            onvalue = self.possValues[i],
            offvalue = -1,
            variable = self.var,
            state = NORMAL,
            command = self.activateSelection,
            width = 15,
            bg = '#' + str(self.colorHexes[i])
         ))
         self.checkList[i].pack()

   """
   Define the functionality for selecting a box.
      If a box is selected then the dependent buttons
      are enabled, otherwise the dependent buttons are disabled.
   """
   def activateSelection(self):
      if self.var.get() != -1:
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = NORMAL
      
      elif self.var.get() == -1:         
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = DISABLED