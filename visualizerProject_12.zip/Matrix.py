"""
Author: John Burns
Last Modified: 5/12/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

"""
The definition for how a LED matrix can be defined.
    Primarily as a x, y, z list of colors. This particular implementation also has a limit on
    how high the value can be set.
There are two modes to call this class's constructor. 
    The default LEDMatrix() with default size of 5x5x7 with a limit on the value of 63.
    The full parameter list can also be entered thanks to *args.
        LEDMatrix(x (int), y (int), z (int), lim (int)) can be called to make a custom matrix.
parameters: *args, either 4 parameters long or 0 parameters long. Otherwise nothing is set.
"""
class LEDMatrix:
    def __init__(self, *args):
        #full parameter list
        if len(args) == 4:
            #Parse expected parameters.
            x, y, z, lim = args
            #Make a matrix of the requested side.
            self.matrix = [[[0 for k in range(z)] for j in range(y)] for i in range(x)]
            #set values.
            self.x = x
            self.y = y
            self.z = z
            self.lim = lim
        elif len(args) == 0:
            #Make a matrix of the default 5x5x7 size.
            self.matrix = [[[0 for k in range(7)] for j in range(5)] for i in range(5)]
            #Set the values to the default values.
            self.x = 5
            self.y = 5
            self.z = 7
            self.lim = 63
    
    #method for getting the x value.
    def getxlen(self):
        return self.x
    
    #method for getting the y value.
    def getylen(self):
        return self.y

    #method for getting the z value.
    def getzlen(self):
        return self.z
    
    #method for getting the lim value.
    def getlim(self):
        return self.lim

    #method for getting the matrix.
    def getMatrix(self):
        return self.matrix

    """
    Sets a value in the matrix.
    Note: implementing the color of a bulb is implented in getRowValue.
    parameters: x, the x value on the layer (int).
                y, the y value on the layer (int).
                z, the layer (int).
                val, the value of the corresponding bulb (int).
    returns: wasProb, whether the value was valid (boolean).
    """
    def setVal(self, x, y, z, val):
        #Allow for problem detection.
        wasProb = False

        #Try to prevent users from entering bogus values.
        if val <= self.lim and val >= 0:
            self.matrix[x][y][z] = val
        else:
            wasProb = True
        
        return wasProb
    
    """
    Retrieve te value from the matrix.
    paramaters: x, the x value on the layer (int).
                y, the y value on the layer (int).
                z, the layer (int).
    returns: value, the value stored in the matrix at that location.
    """
    def getVal(self, x, y, z):
        return self.matrix[x][y][z]

    """
    Provide a way to clear the value. Same as setting the value to 0.
    paramaters: x, the x value on the layer (int).
                y, the y value on the layer (int).
                z, the layer (int).
    """
    def clearVal(self, x, y, z):
        self.matrix[x][y][z] = 0
    
    """
    Provide a way to clear the entire matrix. Rebuilds the matrix by setting every value to 0.
    """
    def clearMatrix(self):
        self.matrix = [[[0 for k in range(self.z)] for j in range(self.y)] for i in range(self.z)]
    
    """
    Provide a way to get an intelligent string of the matrix.
        Matrices are printed as layers from bottom to top.
    returns: outStr, the string to be used (string).
    """
    def toString(self):
        outStr = ""
        for z in range(self.z):
            for y in range(self.y):
                for x in range (self.x):
                    outStr += str(self.matrix[x][y][z])
                    #Don't put strings at the end of printout.
                    if x < self.x - 1:
                        outStr += "   "
                #Put a new line at the end of every row.
                outStr += "\n"
            #Put a new line at the end of every layer except the last one.
            if z < self.z - 1:
                outStr += "\n"
        return outStr

    #Overwriting the default address print statement.
    def __str__(self):
        return self.toString()

    #Written by Henry Gillespie for getting his binary numbers.
    def getRowValue(self, row, color):
        # This function calculates the values that will fill the header file. This creates the correct value (in binary) to push to the LEDs
        # Each value is multiplied by a factor of 2^(3i) to set it to a different value. The color variable allows the writeFile function to
        # get switch between / and % from the values that are in the Colors dictionary in the main visualizer.py file.
        layer = int(row / self.y)
        horizontalRow = row % self.y
        value = 0
        
        for i in range(self.x):
            if color == 0:
                value += int(self.matrix[i][horizontalRow][layer] / 8) * 2**(3*i)
            else:
                value += (self.matrix[i][horizontalRow][layer] % 8) * 2**(3*i)
        return value