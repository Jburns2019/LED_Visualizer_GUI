# File:       pythonCOMport.py
# Author:     Henry Gillespie
# Date:       May 25, 2021
# Purpose:    This program defines the serial connection to the arduino by searching the available COM ports

import serial.tools.list_ports
from tkinter import messagebox

# This function loops through the available COM ports to find the Arduino Nanos provided by Tekbots.
# When it has found the device, the function returns its COM port as a string.
def getPort(description: str, showBox: bool):
    serList = serial.tools.list_ports.comports()
    descriptions = []
    for i in range(len(serList)):
        descriptions.append(serList[i].description) # append description
    try:
        idx = descriptions.index(description)
        if showBox:
            messagebox.showinfo(f"{serList[idx].name} Selected", "Please click okay or close the window to continue.")
        return serList[idx].name # this will return COMX
    except:
        messagebox.showerror(f"{description} was unavailble", "Please ensure you have the desired com inserted." \
                "\nThis will allow you to play animations on the Arduino.\n" \
                "\nNote: You can still make custom animation and view them" \
                "\n\t in the demo tab, you just cannot send them.")
        return ""

# This function returns a list of the descriptions of the available COM ports
def getDescriptions():
    serList = serial.tools.list_ports.comports()
    descriptions = []
    for i in range(len(serList)):
        descriptions.append(serList[i].description)
    return descriptions