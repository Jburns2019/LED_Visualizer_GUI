"""
Author: John Burns
Last Modified: 5/25/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

from Matrix import LEDMatrix
import random
from Colors import *

"""
The definition for how an Animation can be defined.
    Animations are lists of LEDMatrices with an adjustable frame count and speed.
    You can add animation filler functions at the end and then add them to the specialAnimations list.
3 constructors-
    Animation(x, y, z, lim, frameCnt, speed)
        x, number of columns in an LEDMatrix (int).
        y, number of rows in an LEDMatrix (int).
        z, number of layers in an LEDMatrix (int).
        lim, maximum allowable value (int).
        frameCnt, number of frames (int).
        speed, speed of the animation in fps (int).
    Animation(frameCnt, speed)
        Default Matrix() constructor (5x5x7) with a lim of 63.
        frameCnt, number of frames (int).
        speed, speed of the animation in fps (int).
    Animation()
        Default Matrix() constructor (5x5x7) with a lim of 63.
        Default frameCnt of 30.
        Default speed of 20.
"""
class Animation:    
    def __init__(self, *args):
        if len(args) == 6:
            x, y, z, lim, frameCnt, speed = args
            self.animation = [LEDMatrix(x, y, z, lim) for frame in range(frameCnt)]
            self.frameCnt = frameCnt
            self.speed = speed
        elif len(args) == 2:
            frameCnt, speed = args
            self.animation = [LEDMatrix() for frame in range(frameCnt)]
            self.frameCnt = frameCnt
            self.speed = speed
        elif len(args) == 0:
            self.animation = [LEDMatrix() for frame in range(30)]
            self.frameCnt = 30
            self.speed = 30
        
        #Easy way for coder to add more custom animations.
        self.specialAnimations = []
        self.specialAnimations.append(["Sequential", self.seq])
        self.specialAnimations.append(["Random", self.rand])
        self.specialAnimations.append(["Set Color", self.solid])
        self.specialAnimations.append(["Clear", self.clear])

    """
    Method for getting number of frames.
    returns: frameCnt, the number of frames an animation has (int).
    """
    def getNumFrames(self):
        return self.frameCnt
    
    """
    Method for changing the speed of an animation.
    parameters: speed, the speed to run the animation at (in fps, int).
    """
    def setSpeed(self, speed: int):
        self.speed = speed

    """
    Method for getting the Animation's speed.
    returns: speed, the Animations current speed (int).
    """
    def getSpeed(self):
        return self.speed

    """
    Method for adjusting the number of frames.
    parameters: frame, the matrix to edit (int).
                matrix, the matrix to replace the current matrix with (Matrix).
    """
    def setFrame(self, frame: int, matrix: LEDMatrix):
        self.animation[frame] = matrix

    """
    Method for getting a frame from the Animation.
    parameters: frame, the frame of interest (int).
    returns: matrix, the Matrix at the given frame (Matrix).
    """
    def getFrame(self, frame: int):
        return self.animation[frame]
    
    """
    Method for adjusting the number of frames in an Animation.
    parameters: newFrameCnt, the desired frame count for the Animation (int).
    """
    def changeFrameCnt(self, newFrameCnt: int):
        #Prepare for changes in animation.
        newAnimation = []

        #Allow for easy access to this Animation's information.
        x = self.getFrame(0).getxlen()
        y = self.getFrame(0).getylen()
        z = self.getFrame(0).getzlen()
        lim = self.getFrame(0).getlim()
        
        #Ensure that the Animation adds new frames if it does not already have them.
        #Pretty inefficient, but this is plenty fast enough and pretty clear.
        for frame in range(newFrameCnt):
            if frame < self.frameCnt:
                newAnimation.append(self.getFrame(frame))
            else:
                newAnimation.append(LEDMatrix(x, y, z, lim))
        
        #Update the class information.
        self.animation = newAnimation
        self.frameCnt = newFrameCnt

    """
    Method for clearing the animation.
        sets all frames to empty LEDMatrices.
    """
    def clear(self, *args):
        args = list(args)
        args[-1] = 0
        self.fill(args)
    
    """ 
    Customized method for adding sequential colors.
    """
    def seq(self, *args):
        args = list(args)
        args[-1] = -3
        self.fill(args)

    """ 
    Customized method for adding random colors.
    """
    def rand(self, *args):
        args = list(args)
        args[-1] = -2
        self.fill(args)

    def solid(self, *args):
        self.fill(list(args))

    def fill(self, args):
        
        frameLen = self.frameCnt
        if len(args) > 1:
            frameLen = args[0]
        
        counter = 0

        lower = frameLen if len(args) > 1 else 0
        upper = frameLen+1 if len(args) > 1 else frameLen
        for frame in range(lower, upper):
            matrix = self.getFrame(frame)

            layerCnt = matrix.getzlen()
            if len(args) > 2:
                layerCnt = args[1]

            lower = layerCnt if len(args) > 2 else 0
            upper = layerCnt+1 if len(args) > 2 else layerCnt
            for layer in range(lower, upper):
                for y in range(matrix.getylen()):
                    for x in range(matrix.getxlen()):
                        if args[-1] == -2:
                            matrix.setVal(x, y, layer, random.choice(list(HexColors.values())))
                        
                        elif args[-1] == -3:
                            matrix.setVal(x, y, layer, list(HexColors.values())[counter])
                            
                            #Reset the counter when it hits max.
                            if counter < len(list(HexColors.values())) - 1:
                                counter += 1
                            else:
                                counter = 0
                        
                        elif args[-1] >= 0:
                            matrix.setVal(x, y, layer, args[-1])

    """
    Intelligent stringification of the class.
        Shows frame by frame of the Matrices which are layer by layer.
    returns: outStr, the out come of the work (string).
    """
    def toString(self):
        outStr = ""

        for frame in range(self.frameCnt):
            outStr += self.animation[frame].toString()
            if frame < self.frameCnt - 1:
                outStr += ''.join(['-' for i  in range(4 * (self.animation[frame].getxlen()-1) + 1)])
                outStr += "\n"
        
        return outStr

    """
    Overwrite the default string for the class, by showing good information.
    """
    def __str__(self):
        return self.toString()