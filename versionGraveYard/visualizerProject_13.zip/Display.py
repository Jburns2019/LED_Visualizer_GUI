"""
Author: John Burns
Last Modified: 5/14/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

from tkinter import *
from Animation import Animation
from Colors import *

"""
Class made for displaying animations on a window.
parameters: window, a window for displaying a canvas on (Toplevel or Tk)
            animation, the animation to display (Animation)
            backBtnSettings, a way to get back to another window (txt, command)
"""
class Display:
    def __init__(self, window, animation, backBtnSettings):
        #Save window for later.
        self.window = window

        #Create a canvas for the display.
        self.canvas = Canvas(self.window, width = 500, height = 700, bg="#000000")
        self.canvas.pack()

        #Save settings for later.
        self.backBtnSettings = backBtnSettings
        self.playButton = None
        self.backButton = None
        #Create the buttons.
        self.createBtns()

        #Save animation features for later.
        self.animation = animation
        self.speed = int(1000/self.animation.getSpeed())

        #Provide a way to count within the class.
        self.counter = 0

    """
    Creates the buttons used for controlling the animation.
        One button for starting the animation.
        One button for going back to the previous window.
    """
    def createBtns(self):
        #Create a fresh button for a nice layout.
        #Create the play button.
        if self.playButton:
            self.playButton.destroy()
        self.playButton = Button(self.window, text = "Play Animation", command = self.playAnimation)
        self.playButton.pack(anchor = S, side = LEFT)
        
        #Create the back button. Account for the user not having a command (no back button functionality)
        if self.backButton:
            self.backButton.destroy()
        if len(self.backBtnSettings) == 1:
            self.backBtnSettings.append(None)
        self.backButton = Button(self.window, text = self.backBtnSettings[0], command = self.backBtnSettings[1])
        self.backButton.pack(anchor = S, side = LEFT)

    """
    Helpfull function to create a circle with the oval function.
    parameters: x, the x coordinate (int)
                y, the y coordinate (int)
                r, the radius (int)
                kwargs, extra arguments for create oval.
    """
    def createCircle(self, x, y, r, **kwargs):
        return self.canvas.create_oval(x-r, y-r, x+r, y+r, **kwargs)

    """
    Resets the canvas.
    """
    def resetCanvas(self):
        #clear the canvas.
        self.canvas.destroy()
        self.canvas = Canvas(self.window, width = 500, height = 700, bg="#000000")
        self.canvas.pack()

        #Create new buttons.
        self.createBtns()

        #Draw the next frame.
        self.window.after(0, self.drawCircles)

    """
    Draw a frames of the animation.
    """
    def drawCircles(self):
        #Only draw as many frames as there are. Otherwise return.
        if self.counter < self.animation.getNumFrames():
            #Get the matrix.
            matrix = self.animation.getFrame(self.counter)
            for x in range(matrix.getxlen()):
                for z in range(matrix.getzlen()):
                    for y in range(matrix.getylen()):
                        #Create a 3D animation. Going back into the top right.
                        self.createCircle(x*100+y*10+25, 700-z*100-y*10-25, 5, fill = "#"+str(getHex(matrix.getVal(x, matrix.getylen() - 1 - y, z))))

            #Wait the preset amount of time and clear canvas for next animation.
            self.window.after(int(self.speed), self.resetCanvas)

            #Keep track of frame.
            self.counter += 1
    
    """
    Rest the counter every time an animation is played.
    """
    def playAnimation(self):
        self.counter = 0
        #Show the animation.
        self.drawCircles()