"""
Author: John Burns
Last Modified: 5/14/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

from tkinter import *
from Colors import *

"""
Setup the check buttons for setting colors. The panel of checks is colored and named based on the colors the checks represent.
If no color is selected the listOfButtons will become disabled.
parameters: master, the frame the color pannel will be put on (Frame)
            listOfButtons, a list of the dependent buttons (list(Button))
            text, the label used for the color selection (string).
            var, the variable that is changed with clicks (IntVar())
            command, the command to be used (function handle)
            commandlen, the number of commands available (int)
            txtLst, a list of txt for each command (list(string))
"""
class CheckButtonBar:
   def __init__(self, master, listOfButtons, text, var, command=None, commandlen = 0, txtLst = []):
      #Make parameters accessible within the class.
      self.var = var
      self.command = command
      self.commandlen = commandlen
      self.txtLst = txtLst

      #prepare a list.
      self.checkList = []
      self.dependentButtons = listOfButtons

      #Make a labelFrame for describing the pannel.
      self.frame = LabelFrame(master, text=text)
      self.frame.pack()

      #Setup the disabling and reenabling the dependant buttons.
      self.setupChecks()

   """
   Make a list of CheckButtons that are off at -1 and on at the given numeric value.
      the variable, makes it so that the value will be accessible elsewhere without having to check it (auto updates).
   """
   def setupChecks(self):
      #Make a list of CheckButtons and put them in the named pannel.
      #The length of the for loop is dependent on if there are commands expected.
      length = len(list(Colors.values())) if not self.command else self.commandlen
      for i in range(length):
         if not self.command:
            self.checkList.append(Checkbutton(
               self.frame,
               text = list(Colors.keys())[i],
               onvalue = list(Colors.values())[i],
               offvalue = -1,
               variable = self.var,
               command = self.activateSelection,
               width = 15,
               bg = '#' + str(list(HexColors.keys())[i])
            ))
         else:
            self.checkList.append(Checkbutton(
               self.frame,
               text = self.txtLst[i],
               onvalue = i,
               offvalue = -1,
               variable = self.var,
               command = self.activateCommand,
               width = 15,
            ))
         self.checkList[i].pack()

   """
   Define the functionality for selecting a box.
      If a box is enabled use the command, otherwise do nothing.
   """
   def activateCommand(self):
      if self.var.get() != -1:
         self.command()

   """
   Define the functionality for selecting a box.
      If a box is selected then the dependent buttons
      are enabled, otherwise the dependent buttons are disabled.
   """
   def activateSelection(self):
      if self.var.get() != -1:
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = NORMAL
      
      elif self.var.get() == -1:         
         for i in range(len(self.dependentButtons[0])):
            self.dependentButtons[0][i]['state'] = DISABLED