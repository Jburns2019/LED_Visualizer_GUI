#!/usr/bin/python

from tkinter import *
from tkinter import messagebox
from Animation import Animation
from ArduinoInterface import *
from Layer import LEDLayer
from CheckMarkList import CheckButtonBar
from Slider import SliderFrames
import sys

"""
Colors that are used for naming the tabs.
"""
Colors = {'Off': 0, 'Dim Blue': 1, 'Dim Green': 2, 'Dim Cyan': 3, \
            'Dim Red': 4, 'Dim Purple': 5, 'Dim Yellow': 6, 'Dim White': 7, \
            'Blue': 9, 'Blue-Cyan': 11, 'Blue-Purple': 13, 'Baby Blue': 15, \
            'Green': 18, 'Green-Cyan': 19, 'Green-Yellow': 22, 'Green-White': 23, \
            'Cyan': 27, 'Cyan-White': 31, 'Red': 36, 'Red-Purple': 37, \
            'Orange': 38, 'Pink': 39, 'Purple': 45, 'Purple-White': 47, \
            'Yellow': 54, 'Yellow-White': 55, 'White': 63}

"""
Corresponding hex values for the above colors. Retrieved from analysis done on possible colors.
"""
HexColors = {'000000': 0, '00007f': 1, '007f00': 2, '007f7f': 3, \
             '7f0000': 4, '7f007f': 5, '7f7f00': 6, '7f7f7f': 7, \
             '0000ff': 8, '007fff': 11, '7f00ff': 13, '7f7fff': 15, \
             '00ff00': 18, '00ff7f': 19, '7fff00': 22, '7fff7f': 23, \
             '00ffff': 27, '7fffff': 31, 'ff0000': 36, 'ff007f': 37, \
             'ff7f00': 38, 'ff7f7f': 39, 'ff00ff': 45, 'ff7fff': 47, \
             'ffff00': 54, 'ffff7f': 55, 'ffffff': 63}

"""
A class that sets up the visualizer multiwindow.
The first window sends numeric data to sendValToArd(num) based on the chosen animation.
The second window is built to customize animation 4, 5, and 6.
All three animations are saved during the session, but would have to be rebuilt if the session was closed.
Clicking submit sends the animations to animationsForHeader(animations) based on the selections made in the interface.
To change an animation, select the animation (default 4), choose a frame (default 0), choose a layer (default 0),
   choose a color (default none or black), finally click an LED.
You will not only keep animations when going to other tabs, you will also keep the place you were last working on that animation
   when you come back.
The speed of an animation is adjustable. Just adjust the slider.
The maximum frame count of an animation is adjustable. Just adjust the slider.
   Adjusting the maximum frame count will delete frames past that frame.
   You needn't worry about the current frame slider. It will be always be in a valid state (will be reduced if max count is lower).

For the curious... non of the features of the default animation (1, 2, and 3) are adjustable. Which is why they don't show up under
   advanced settings bar.
"""
class MultiWindow:
   def __init__(self, master, hexColors, colors):
      self.master = master
      self.secondaryWin = None
      self.hexColors = hexColors
      self.colors = colors

      self.currentBtnLst = [None]
      self.currentBtnLayer = None

      self.sliders = None

      #setup global variables that can be changed with widget actions.
      #These do not change between animations.
      self.colorChosen = IntVar()
      self.animationChosen = IntVar()

      #These do change between animations, so there is 1 for each animation.
      self.animations = []
      self.speeds = []
      self.frameCnts = []
      self.layers = []
      self.frames = []
      for i in range(3):
         self.animations.append(Animation())
         self.speeds.append(IntVar(value = self.animations[self.animationChosen.get()].getSpeed()))
         self.frameCnts.append(IntVar(value = self.animations[self.animationChosen.get()].getNumFrames()))
         self.layers.append(IntVar())
         self.frames.append(IntVar())

      #layout the buttons and their functionality.
      self.setupMainWindow()

      #Allow for creating another window with
      self.nextBtn = Button(self.master, text="Advanced Settings", width = 15, command=self.advancedSettingOptions)
      self.nextBtn.grid(row = 2, column = 1)

   def setupMainWindow(self):
      counter = 0
      for i in range(2):
         for j in range(3):
            Button(basic, text =f"Animation {counter+1}", width = 15, command = self.choiceLambda(counter)).grid(row = i, column = j)
            counter += 1

   def choiceLambda(self, num):
      return lambda: self.displayChoice(num)

   #Functions of animations
   def displayChoice(self, num):
      messagebox.showinfo(f"UpTop{num}", str(num))
      sendValToArd(num)

   def sendAnimationsLam(self, animations):
      return lambda: animationsForHeader(animations)

   def advancedSettingOptions(self):
      if not self.secondaryWin:
         self.secondaryWin = Toplevel()
         self.secondaryWin.protocol("WM_DELETE_WINDOW", sys.exit)

         tabFrame = Frame(self.secondaryWin)
         actionFrame = Frame(self.secondaryWin)
         tabFrame.pack(side = TOP, anchor = W)
         actionFrame.pack(side = TOP, anchor = W)

         self.btnFrame = None
         
         for i in range(3):
            Button(tabFrame, text =f"Animation {i+4}", width = 12, command = self.selectActLam(i)).pack(side = LEFT)
         Button(tabFrame, text="Basic Settings", width = 12, command=self.basicSettingOptions).pack(side = LEFT)
         Button(tabFrame, text="Submit", bg = 'green', width = 12, command = self.sendAnimationsLam(self.animations)).pack(side = LEFT)

         self.secondaryWin.geometry("475x721")
         self.master.withdraw()

         self.setupActionFrame(actionFrame)
      else:
         self.secondaryWin.deiconify()
         self.master.withdraw()
      
   def basicSettingOptions(self):
      self.secondaryWin.withdraw()
      self.master.deiconify()
   
   def setupActionFrame(self, actionFrame):
      self.btnFrame = Frame(actionFrame)
      colorSelFrame = Frame(actionFrame)

      colorSelFrame.pack(side = LEFT, fill = Y)
      self.btnFrame.pack(side = LEFT, fill = BOTH)

      self.sliders = SliderFrames(self.btnFrame, self.getInfo())

      self.LEDSelectionSetup()
      self.colorSelectorSetup(colorSelFrame)      

   def getInfo(self):
      matrix = self.animations[self.animationChosen.get()].getFrame(self.frames[self.animationChosen.get()].get())
      posInfo = [['Choose Layer', 0, matrix.getzlen()-1, self.layers[self.animationChosen.get()], self.selAct], \
         ['Choose Frame', 0, self.animations[self.animationChosen.get()].getNumFrames()-1, self.frames[self.animationChosen.get()], self.selAct]]
         
      featureInfo = [['Choose Speed (fps)', 1, self.animations[self.animationChosen.get()].getSpeed(), self.speeds[self.animationChosen.get()], self.selAct], \
         ['Max Frame Count', 1, self.animations[self.animationChosen.get()].getNumFrames(), self.frameCnts[self.animationChosen.get()], self.selAct]]
      
      return [posInfo, featureInfo]

   def LEDSelectionSetup(self):      
      matrix = self.animations[self.animationChosen.get()].getFrame(self.frames[self.animationChosen.get()].get())
      self.currentBtnLayer = LEDLayer(self.btnFrame, matrix, self.colorChosen, self.layers[self.animationChosen.get()], self.hexColors)
      self.currentBtnLst[0] = self.currentBtnLayer.buttonLst
   
   def colorSelectorSetup(self, colorSelFrame):
      CheckButtonBar(
         colorSelFrame, 
         self.currentBtnLst, 
         'Possible Colors', 
         len(list(self.colors.values())),
         list(self.hexColors.keys()),
         list(self.colors.keys()),
         list(self.hexColors.values()),
         self.colorChosen
      )

   def selectActLam(self, animSelected):
      return lambda: self.selAnimAct(animSelected)

   def selAnimAct(self, animSelected):
      self.currentBtnLayer.remove()

      self.animationChosen.set(animSelected)

      LAYER = 0
      FRAME = 1
      SPEED = 2
      FRAMECNT = 3

      scales = []
      for strip in range(len(self.sliders.listofscaleFrame_sels)):
         for scale in range(len(self.sliders.listofscaleFrame_sels[strip])):
            scales.append(self.sliders.listofscaleFrame_sels[strip][scale][1])

      scales[LAYER].set(self.layers[self.animationChosen.get()].get())
      scales[FRAME].set(self.frames[self.animationChosen.get()].get())
      scales[SPEED].set(self.speeds[self.animationChosen.get()].get())
      scales[FRAMECNT].set(self.frameCnts[self.animationChosen.get()].get())

      chosenAnimation = self.animations[self.animationChosen.get()]
      chosenMatrix = chosenAnimation.getFrame(self.frames[self.animationChosen.get()].get())
      self.currentBtnLayer = LEDLayer(self.btnFrame, chosenMatrix, self.colorChosen, self.layers[self.animationChosen.get()], self.hexColors)
      self.currentBtnLst[0] = self.currentBtnLayer.buttonLst
   
   def selAct(self, animSelected = None):
      self.currentBtnLayer.remove()

      LAYER = 0
      FRAME = 1
      SPEED = 2
      FRAMECNT = 3

      scales = []
      for strip in range(len(self.sliders.listofscaleFrame_sels)):
         for scale in range(len(self.sliders.listofscaleFrame_sels[strip])):
            scales.append(self.sliders.listofscaleFrame_sels[strip][scale][1])

      self.layers[self.animationChosen.get()].set(scales[LAYER].get())
      self.frameCnts[self.animationChosen.get()].set(scales[FRAMECNT].get())

      if scales[FRAME].get() < scales[FRAMECNT].get():
         self.frames[self.animationChosen.get()].set(scales[FRAME].get())
      else:
         scales[FRAME].set(scales[FRAMECNT].get()-1)
      
      self.speeds[self.animationChosen.get()].set(scales[SPEED].get())
      

      chosenAnimation = self.animations[self.animationChosen.get()]
      chosenAnimation.setSpeed(self.speeds[self.animationChosen.get()].get())
      chosenAnimation.changeFrameCnt(self.frameCnts[self.animationChosen.get()].get())

      frameNum = 0
      if chosenAnimation.getNumFrames() <= self.frames[self.animationChosen.get()].get():
         frameNum = chosenAnimation.getNumFrames() - 1
      else:
         frameNum = self.frames[self.animationChosen.get()].get()
         
      chosenMatrix = chosenAnimation.getFrame(frameNum)
      self.currentBtnLayer = LEDLayer(self.btnFrame, chosenMatrix, self.colorChosen, self.layers[self.animationChosen.get()], self.hexColors)
      self.currentBtnLst[0] = self.currentBtnLayer.buttonLst

basic = Tk()
basic.title("LED Visualizer GUI")
basic.geometry("347x80")

window = MultiWindow(basic, HexColors, Colors)
basic.protocol("WM_DELETE_WINDOW", basic.destroy)
basic.mainloop()
