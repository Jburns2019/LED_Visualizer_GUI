from tkinter import *
import numpy as np

class LEDLayer:
   def __init__(self, master, matrix, colorChosen, layerChosen, hexColors):
      self.frame = LabelFrame(master, text = 'Select LEDs Below')
      self.frame.pack(anchor = W)

      self.matrix = matrix
      self.layerChosen = layerChosen
      self.layer = np.array(self.matrix.getMatrix())[:, :, self.layerChosen.get()].tolist()
      self.colorChosen = colorChosen

      self.hexColors = hexColors
      self.buttonLst = []

      counter = 0
      stripFrames = []
      for y in range(len(self.layer[0])):
         stripFrames.append(Frame(self.frame))
         stripFrames[y].pack(anchor = W, pady = 10)

         for x in range(len(self.layer)):
            hxVals = list(self.hexColors.keys())
            numVals = list(self.hexColors.values())
            indexOfVal = numVals.index(self.layer[x][y])

            btn = Button(stripFrames[y], bg = '#' + str(hxVals[indexOfVal]), text = f"({x}, {y})", command = self.defAction(x, y, counter))
            btn.pack(side = LEFT, padx = 10)
            self.buttonLst.append(btn)
            counter += 1
   
   def remove(self):
      self.frame.pack_forget()
      self.frame.destroy()

   def defAction(self, x, y, btnRef):
      return lambda: self.changeMatrix(x, y, btnRef)

   def changeMatrix(self, x, y, btnRef):
      self.matrix.setVal(x, y, self.layerChosen.get(), self.colorChosen.get())
      self.layer = np.array(self.matrix.getMatrix())[:, :, self.layerChosen.get()].tolist()

      hxVals = list(self.hexColors.keys())
      numVals = list(self.hexColors.values())
      indexOfVal = numVals.index(self.colorChosen.get())
      self.buttonLst[btnRef]['bg'] = '#' + str(hxVals[indexOfVal])

      print(self.layer)
      print('-------------------\n')