def sendValToArd(val):
    print(val)

