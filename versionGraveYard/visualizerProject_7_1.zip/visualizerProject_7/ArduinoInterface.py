import os

def sendValToArd(val):
    # This function sends the input value to Serial Port COM3
    print(val)
    os.system(r'mode COM3 BAUD=9600 PARITY=n DATA=8')

    # The following lines make a raw string with a variable in it. 'string' is parsed as an f-string with special characters and a variable
    # Then it is converted to a raw string with the variable in place

    string = f'set /p x="{val}" <nul >\\\\.\COM3' # in f-strings, '\' is a special character, so '\\' becomes '\'
    print(string)
    os.system(r"{}".format(string)) # raw strings ignore otherwise special characters

def animationsForHeader(animations):
    # This function writes a header file and then uploads the arduino code, which calls the header file
    writeFile(animations)
    os.system(r'arduino --upload C:\Users\henry\Documents\Arduino\JuniorDesign_PreProgrammedAnimations\JuniorDesign_PreProgrammedAnimations.ino')


def writeFile(animations):
    headerFile = open("headerFile.h", 'w')
    headerFile.write("#ifndef headerFile\n#define headerFile\n\n")
    # in f-strings, '{' is a special character to open variables, so '{{' will become '{' in the header file
    headerFile.write(f"const PROGMEM uint16_t customLengths[3] = {{{animations[0].getNumFrames()}, {animations[1].getNumFrames()}, {animations[2].getNumFrames()}}};\n")
    headerFile.write(f"const PROGMEM uint16_t customSpeeds[3] = {{{framesToMicros(animations[0].getSpeed())}, {framesToMicros(animations[1].getSpeed())}, {framesToMicros(animations[2].getSpeed())}}};\n\n")
    headerFile.write("const PROGMEM uint16_t colorArr[3][2][30][35] = {")
    

    for i in range(len(animations)): # for each animation
            headerFile.write("\n{") # open animation array
            for color in range(2): # for each of the two color values to be passed
                headerFile.write("{") # open color array
                for frame in range(30): # for each frame
                    headerFile.write("{") # open frame array
                    for LED_row in range(35):
                        if frame < animations[i].getNumFrames(): # if this frame exists
                            headerFile.write(str(int(animations[i].getFrame(frame).getRowValue(LED_row,color))))
                        else:
                            headerFile.write("0") # if frame > number of frames, fill it with 0
                        if LED_row != 34:
                            headerFile.write(', ') # do not use a ',' after the last value in the array
                    # close frame arrays
                    if frame != 29:
                        headerFile.write('}, ')
                    else:
                        headerFile.write('}')
                # close color arrays
                if color != 1:
                    headerFile.write('},\n ')
                else:
                    headerFile.write('}')
            # close animation arrays
            if i != len(animations)-1:
                headerFile.write('}, ')
            else:
                headerFile.write('}')

    headerFile.write("};\n\n#endif") # close complete array
    headerFile.close()

def framesToMicros(fps):
    # This function converts a frames per second value to microseconds per frame
    return round(1000000 / fps)