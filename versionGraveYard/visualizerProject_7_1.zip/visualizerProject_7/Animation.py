from Matrix import LEDMatrix
import copy

class Animation:    
    def __init__(self, *args):
        if len(args) == 6:
            x, y, z, lim, frameCnt, speed = args
            self.animation = [LEDMatrix(x, y, z, lim) for frame in range(frameCnt)]
            self.frameCnt = frameCnt
            self.speed = speed
        elif len(args) == 2:
            frameCnt, speed = args
            self.animation = [LEDMatrix() for frame in range(frameCnt)]
            self.frameCnt = frameCnt
            self.speed = speed
        elif len(args) == 0:
            self.animation = [LEDMatrix() for frame in range(30)]
            self.frameCnt = 30
            self.speed = 20

    def getNumFrames(self):
        return self.frameCnt
    
    def setSpeed(self, speed):
        self.speed = speed

    def getSpeed(self):
        return self.speed

    def setFrame(self, frame, matrix):
        self.animation[frame] = matrix

    def getFrame(self, frame):
        return self.animation[frame]

    def changeFrameCnt(self, newFrameCnt):
        newAnimation = []

        x = self.getFrame(0).getxlen()
        y = self.getFrame(0).getylen()
        z = self.getFrame(0).getzlen()
        lim = self.getFrame(0).getlim()

        for frame in range(newFrameCnt):
            if frame < self.frameCnt:
                newAnimation.append(self.getFrame(frame))
            else:
                newAnimation.append(LEDMatrix(x, y, z, lim))
        
        self.animation = newAnimation
        self.frameCnt = newFrameCnt

    def clearAnimation(self):
        for frame in range(frameCnt):
            self.animation[frame].clearMatrix()
    
    def toString(self):
        outStr = ''

        for frame in range(self.frameCnt):
            outStr += self.animation[frame].toString()
            if frame < self.frameCnt - 1:
                outStr += ''.join(['-' for i  in range(4 * (self.animation[frame].getxlen()-1) + 1)])
                outStr += "\n"
        
        return outStr

    def __str__(self):
        return self.toString()