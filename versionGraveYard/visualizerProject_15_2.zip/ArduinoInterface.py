# File:       ArduinoInterface.py
# Author:     Henry Gillespie
# Date:       May 16, 2021
# Purpose:    This program defines functions that communicate with the Arduino

import os
from Animation import Animation
import pythonCOMport as com

def sendValToArd(val:int,port:str):
    # This function sends the input value to Serial Port COM3
    print(val)
    portNum = com.getPort(port, False)
    if portNum == "":
        portNum = "COM3"
    
    setMode = f'mode {portNum} BAUD=9600 PARITY=n DATA=8'
    os.system(r"{}".format(setMode))
    # os.system(r'mode COM3 BAUD=9600 PARITY=n DATA=8')

    # The following lines make a raw string with a variable in it. 'string' is parsed as an f-string with special characters and a variable
    # Then it is converted to a raw string with the variable in place

    string = f'set /p x="{val}" <nul >\\\\.\{portNum}' # in f-strings, '\' is a special character, so '\\' becomes '\'
    print(string)
    os.system(r"{}".format(string)) # raw strings ignore otherwise special characters

def animationsForHeader(animations: list, port:str):
    # This function writes a header file and then uploads the arduino code, which calls the header file
    writeFile(animations)
    print(os.getcwd())
    portNum = com.getPort(port, False)
    uploadStr = f'arduino --upload --port {portNum} JuniorDesign_PreProgrammedAnimations\JuniorDesign_PreProgrammedAnimations.ino'
    # os.system(r'arduino --upload JuniorDesign_PreProgrammedAnimations\JuniorDesign_PreProgrammedAnimations.ino')
    os.system(r"{}".format(uploadStr))

def writeFile(animations: list[Animation]):
    headerFile = open("JuniorDesign_PreProgrammedAnimations\headerFile.h", 'w')
    headerFile.write("#ifndef headerFile\n#define headerFile\n\n")
    # in f-strings, '{' is a special character to open variables, so '{{' will become '{' in the header file
    headerFile.write(f"const PROGMEM uint16_t customLengths[3] = {{{animations[0].getNumFrames()}, {animations[1].getNumFrames()}, {animations[2].getNumFrames()}}};\n")
    headerFile.write(f"const PROGMEM unsigned long customSpeeds[3] = {{{framesToMicros(animations[0].getSpeed())}, {framesToMicros(animations[1].getSpeed())}, {framesToMicros(animations[2].getSpeed())}}};\n\n")
    headerFile.write("const PROGMEM uint16_t colorArr[3][2][30][35] = {")
    

    for i in range(len(animations)): # for each animation
            headerFile.write("\n{") # open animation array
            for color in range(2): # for each of the two color values to be passed
                headerFile.write("{") # open color array
                for frame in range(30): # for each frame
                    headerFile.write("{") # open frame array
                    for LED_row in range(35):
                        if frame < animations[i].getNumFrames(): # if this frame exists
                            headerFile.write(str(int(animations[i].getFrame(frame).getRowValue(LED_row,color))))
                        else:
                            headerFile.write("0") # if frame > number of frames, fill it with 0
                        if LED_row != 34:
                            headerFile.write(', ') # do not use a ',' after the last value in the array
                    # close frame arrays
                    if frame != 29:
                        headerFile.write('}, ')
                    else:
                        headerFile.write('}')
                # close color arrays
                if color != 1:
                    headerFile.write('},\n ')
                else:
                    headerFile.write('}')
            # close animation arrays
            if i != len(animations)-1:
                headerFile.write('}, ')
            else:
                headerFile.write('}')

    headerFile.write("};\n\n#endif") # close complete array
    headerFile.close()

def framesToMicros(fps: int):
    # This function converts a frames per second value to microseconds per frame
    return round(1000000 / fps)