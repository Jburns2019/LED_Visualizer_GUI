#!/usr/bin/python

from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from Matrix import LEDMatrix
from Animation import Animation
from ArduinoInterface import *

Colors = {'Off': 0, 'Dim Blue': 1, 'Blue': 8, 'Dim Cyan': 3, \
            'Cyan': 24, 'Blue-Cyan': 10, 'Green-Cyan': 17, 'Dim Green': 2, \
            'Green': 16, 'Yellow': 48, 'Dim Yellow': 6, 'Green-Yellow': 20, \
            'Red-Yellow': 34, 'Dim Red': 4, 'Red': 32, 'Purple': 40, \
            'Dim Purple': 5, 'Red-Purple': 33, 'Blue-Purple': 12, \
            'Dim White': 7, 'White': 56, 'Pink': 35, 'Baby Blue': 14, \
            'Green-White': 21, 'Yellow-White': 49, 'Cyan-White': 28, 'Purple-White': 42}

#creates initial "basic window 
class MultiWindow:
   def __init__(self, master):
      self.master = master
      self.secondaryWin = None
      counter = 0
      animate = lambda val: firstAnimation(val)
      for i in range(2):
         for j in range(3):
            Button(basic, text =f"Animation {counter+1}", width = 15, command = choiceLambda(counter)).grid(row = i, column = j)
            counter += 1

      self.nextBtn = Button(self.master, text="Advanced Settings", width = 15, command=self.advancedSettingOptions)
      self.nextBtn.grid(row = 2, column = 1)
   
   def advancedSettingOptions(self):
      if not self.secondaryWin:
         self.secondaryWin = Toplevel()
         basicBtn = Button(self.secondaryWin, text="Basic Settings", command=self.basicSettingOptions)
         basicBtn.pack()

         self.secondaryWin.geometry("500x500")
         self.master.withdraw()

         scrollbar = Scrollbar(self.secondaryWin, jump = 0)
         scrollbar.pack( side = RIGHT, fill = Y )
         mylist = Listbox(self.secondaryWin, yscrollcommand = scrollbar.set )
         for line in range(30):
            mylist.insert(END, "Frame Number: " + str(line))
         mylist.pack(side = RIGHT, fill = BOTH)
         scrollbar.config(command = mylist.yview)
      else:
         self.secondaryWin.deiconify()
         self.master.withdraw()
      
   def basicSettingOptions(self):
      self.secondaryWin.withdraw()
      self.master.deiconify()

def choiceLambda(num):
   return lambda: displayChoice(num)

#Functions of animations
def displayChoice(num):
   messagebox.showinfo(f"UpTop{num}", str(num))
   sendValToArd(num)

basic = Tk()
basic.title("LED Visualizer GUI")
basic.geometry("347x80")

window = MultiWindow(basic)
basic.mainloop()
