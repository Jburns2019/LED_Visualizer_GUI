"""
Author: John Burns
Last Modified: 5/15/2021
OSU Email Address: burnsjo@oregonstate.edu
Course Number ECE 342
Project: LED Visualizer Group 2           Due Date: 5/14/2021
"""

from tkinter import *
from typing import Callable, Collection
from Animation import Animation
from Colors import *
import sys

"""
Class made for displaying animations on a window.
    Animates at the speed of the animation.
    Play button and back button is disabled while animation is playing.
    Pause button pauses the animation in frame (togglable for easy quick clicking)
    Stop button enables play button and back button as well as restarts the animation.
parameters: window, a window for displaying a canvas on (Toplevel)
            animation, the animation to display (Animation)
            backBtnSettings, a way to get back to another window (txt, command)
"""
class Display:
    def __init__(self, window: Toplevel, animation: Animation, backBtnSettings: list):
        #Save window for later.
        self.window = window
        self.window.protocol("WM_DELETE_WINDOW", sys.exit)

        self.play = BooleanVar(value = True)

        #Make a frame for the buttons.
        self.frame = Frame(self.window)
        self.frame.pack(anchor = W)

        #Save settings for later.
        self.backBtnSettings = backBtnSettings
        #Create the buttons.
        self.createBtns(self.frame)

        #Create a canvas for the display.
        self.canvas = Canvas(self.window, width = 500, height = 700, bg="#000000")
        self.canvas.pack()

        #Save animation features for later.
        self.animation = animation
        self.speed = int(1000/self.animation.getSpeed())

        #Provide a way to count within the class.
        self.counter = 0

    """
    Creates the buttons used for controlling the animation.
        One button for starting the animation.
        One button for going back to the previous window.
    """
    def createBtns(self, frame: Frame):
        #Create a fresh button for a nice layout.
        #Create the play button.
        self.playButton = Button(frame, text = "Play Animation", command = self.playAnimation)
        self.playButton.pack(side = LEFT)

        #Create the back button. Account for the user not having a command (no back button functionality)
        if len(self.backBtnSettings) == 1:
            self.backBtnSettings.append(None)
        self.backButton = Button(frame, text = self.backBtnSettings[0], command = self.backBtnSettings[1])
        self.backButton.pack(side = LEFT)
        
        #Create a togglable pause button.
        self.pauseButton = Checkbutton(frame, text="Pause Animation", onvalue=False, offvalue=True, variable=self.play, activeforeground="black")
        self.pauseButton.pack(side = LEFT)

        self.stopButton = Button(frame, text = "Stop Animation", command = self.stopAnimation)
        self.stopButton.pack(side = LEFT)

    """
    Helpfull function to create a circle with the oval function.
    parameters: x, the x coordinate (int)
                y, the y coordinate (int)
                r, the radius (int)
                kwargs, extra arguments for create oval.
    """
    def createCircle(self, x: int, y: int, r: int, **kwargs):
        return self.canvas.create_oval(x-r, y-r, x+r, y+r, **kwargs)

    """
    Resets the canvas.
    """
    def resetCanvas(self):
        #clear the canvas.
        self.canvas.destroy()
        self.canvas = Canvas(self.window, width = 500, height = 700, bg="#000000")
        self.canvas.pack()

        #Draw the next frame.
        self.window.after(0, self.drawCircles)

        #If the animation is done, reenable the play and back button.
        if self.counter == self.animation.getNumFrames():
            self.playButton['state'] = NORMAL
            self.backButton['state'] = NORMAL

    """
    Draw a frames of the animation.
    """
    def drawCircles(self):
        #If paused, just loop. This allows tkinter actions to be registered.
        if not self.play.get() and self.counter != self.animation.getNumFrames():
            #Wait the preset amount of time and clear canvas for next animation.
            self.window.after(0, self.drawCircles)
        
        #Otherwise only draw as many frames as there are. Otherwise return.
        elif self.counter < self.animation.getNumFrames():
            #Get the matrix.
            matrix = self.animation.getFrame(self.counter)
            for x in range(matrix.getxlen()):
                for z in range(matrix.getzlen()):
                    for y in range(matrix.getylen()):
                        #Create a 3D animation. Going back into the top right.
                        self.createCircle(x*100+y*10+25, 700-z*100-y*10-25, 5, fill = "#"+str(getHex(matrix.getVal(x, matrix.getylen() - 1 - y, z))))

            #Keep track of frame.
            self.counter += 1
            
            #Wait the preset amount of time and clear canvas for next animation.
            self.window.after(self.speed, self.resetCanvas)

    """
    Rest the counter every time an animation is played.
    """
    def playAnimation(self):
        self.counter = 0
        
        self.playButton['state'] = DISABLED
        self.backButton['state'] = DISABLED

        #Show the animation.
        self.drawCircles()
    
    """
    
    """
    def stopAnimation(self):
        self.counter = self.animation.getNumFrames()
        
        if self.playButton['state'] == DISABLED:
            self.play.set(True)

            self.playButton['state'] = NORMAL
            self.backButton['state'] = NORMAL

