from tkinter import *
import numpy as np

"""
Built for the display and edit of the layer values of a given layer and matrix.
   It is implemented in such a way that buttons are only selectable if a color is selected.
   The buttons will also change color in accordance with the color chosen.
paramaters: master, the frame that button layer will be placed into (Frame).
            matrix, the LED layer is within (Matrix).
            colorChosen, the variable assigned for changing a button's color (IntVar)
            layerChosen, the variable assigned for keeping track of the desired layer (IntVar).
            hexColors, the way to reference colors and the values that are assigned them (dictionary).
"""
class LEDLayer:
   def __init__(self, master, matrix, colorChosen, layerChosen, hexColors):
      #Make a label frame that tells the user how to use it.
      self.frame = LabelFrame(master, text = 'Select LEDs Below')
      self.frame.pack(anchor = W)

      #Make the parameters easily accessable elsewhere.
      self.matrix = matrix
      self.layerChosen = layerChosen
      #Get the row and column of a set layer, using numpys easy splicing.
      self.layer = np.array(self.matrix.getMatrix())[:, :, self.layerChosen.get()].tolist()
      self.colorChosen = colorChosen

      self.hexColors = hexColors
      #Make the buttons available to the class.
      self.buttonLst = []

      counter = 0
      #Create strips of buttons.
      stripFrames = []
      for y in range(len(self.layer[0])):
         stripFrames.append(Frame(self.frame))
         stripFrames[y].pack(anchor = W, pady = 10)

         for x in range(len(self.layer)):
            #Find the hex for the color chosen.
            hxVals = list(self.hexColors.keys())
            numVals = list(self.hexColors.values())
            indexOfVal = numVals.index(self.layer[x][y])
            
            #Make the button unusable if no color has been selected.
            state = NORMAL if colorChosen.get() != -1 else DISABLED

            #Make a button with the bg color of that layer's value, name it and define it based on its positioning.
            btn = Button(stripFrames[y], bg = '#' + str(hxVals[indexOfVal]), text = f"({x}, {y})", state = state, command = self.defAction(x, y, counter))
            btn.pack(side = LEFT, padx = 10)
            #Put the button in the list.
            self.buttonLst.append(btn)
            counter += 1
   
   """
   Make it easy to remove the layer so that it can be easily replaced.
   """
   def remove(self):
      self.frame.pack_forget()
      self.frame.destroy()

   """
   Define the action for an active button in the button layer being clicked.
   parameters: x, the column number in the button layer (int).
               y, the row number in the button layer (int).
               btnRef, the direct reference to the button in the grid created (Button).
   returns: function handle, a preset function handle that can be run whenever an even is read (lambda).
   """
   def defAction(self, x, y, btnRef):
      return lambda: self.changeMatrix(x, y, btnRef)

   """
   Change the matrix based on the actions of the user.
      When a button is clicked (that is clickable), the color of that button should change to the chosen color
      and the matrix value should also change.
   parameters: x, the column number in the button layer (int).
               y, the row number in the button layer (int).
               btnRef, the direct reference to the button in the grid created (Button).
   """
   def changeMatrix(self, x, y, btnRef):
      #Update the layer based on the user's action.
      self.matrix.setVal(x, y, self.layerChosen.get(), self.colorChosen.get())
      self.layer = np.array(self.matrix.getMatrix())[:, :, self.layerChosen.get()].tolist()

      #Set the color of the button based on the user's selection.
      hxVals = list(self.hexColors.keys())
      numVals = list(self.hexColors.values())
      indexOfVal = numVals.index(self.colorChosen.get())
      self.buttonLst[btnRef]['bg'] = '#' + str(hxVals[indexOfVal])

      #Debugging content.
      #print(self.layer)
      #print('-------------------\n')