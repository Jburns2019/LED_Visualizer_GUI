#Dummy file for showing what Henry should be referencing in his block.
#Notice that sendValToArd gets a value (showing which animation was chosen)
#Notice that animationsForHeader gets the list of animations (edited by the user).
#This demonstrates the connection between the two blocks. The implementation shown below
#demonstates not only how to use the parameters, but that the gui is producing the expected results.
def sendValToArd(val):
    print(val)

def animationsForHeader(animations):
    for animation in animations:
        print(animation)
        print('-------------------------\n')